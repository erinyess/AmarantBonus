package com.example.amarantbonuscompose

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import kotlinx.coroutines.*
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import io.ktor.client.*
import io.ktor.client.engine.cio.*
import io.ktor.client.request.*
import io.ktor.client.statement.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(navController: NavHostController) {
    var currentLanguage by remember { mutableStateOf("RUS") }
    var phoneNumber by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val phoneFocusRequester = remember { FocusRequester() }
    val passwordFocusRequester = remember { FocusRequester() }

    Box(
        modifier = Modifier
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFF6A0DAD), Color(0xFF4A148C))
                )
            )
    ) {
        Column(
            modifier = Modifier
                .padding(horizontal = 20.dp, vertical = 30.dp),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Логотип
            Image(
                painter = painterResource(id = R.drawable.new_image), // Замените на ваш ресурс
                contentDescription = "Логотип",
                modifier = Modifier.size(100.dp)
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Заголовок "Бонусная система"
            Text(
                text = "БОНУСНАЯ СИСТЕМА",
                color = Color(0xFFFFC107),
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            // Поле для ввода номера телефона
            Text(
                text = "НОМЕР ТЕЛЕФОНА",
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.Start)
            )

            // Поле ввода телефона
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .width(280.dp) // Установите фиксированную ширину
                    .height(30.dp)
                    .border(1.dp, Color.White, RoundedCornerShape(10.dp))
                    .padding(horizontal = 8.dp)
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.ic_phone), // Замените на ваш ресурс
                    contentDescription = "+7",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )

                Spacer(modifier = Modifier.width(8.dp))

                TextField(
                    value = phoneNumber,
                    onValueChange = { phoneNumber = it },
                    placeholder = { Text("777 000 00 01", color = Color.Gray) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(phoneFocusRequester),
                    colors = TextFieldDefaults.textFieldColors(
                        containerColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        cursorColor = Color.White
                    ),
                    singleLine = true
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Поле для ввода пароля
            Text(
                text = "ПАРОЛЬ",
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.Start)
            )

            // Поле ввода пароля
            TextField(
                value = password,
                onValueChange = { password = it },
                visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                        Icon(
                            imageVector = if (isPasswordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                            contentDescription = if (isPasswordVisible) "Скрыть пароль" else "Показать пароль",
                            tint = Color.White
                        )
                    }
                },
                placeholder = { Text("Пароль", color = Color.Gray) },
                modifier = Modifier
                    .width(320.dp) // Установите фиксированную ширину
                    .height(50.dp)
                    .focusRequester(passwordFocusRequester),
                colors = TextFieldDefaults.textFieldColors(
                    containerColor = Color(0xFF3C3C3C),
                    unfocusedIndicatorColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    cursorColor = Color.White
                ),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Кнопка «Войти»
            Button(
                onClick = {
                    isLoading = true
                    coroutineScope.launch {
                        val formattedPhone = phoneNumber.replace(" ", "").replace("-", "") // Убираем пробелы и дефисы
                        val result = verifyLogin(formattedPhone)
                        isLoading = false
                        if (result) {
                            navController.navigate("main_screen")
                        } else {
                            withContext(Dispatchers.Main) {
                                Toast.makeText(context, "Неверный пароль", Toast.LENGTH_LONG).show()
                            }
                        }
                    }
                },
                modifier = Modifier
                    .width(320.dp) // Установите фиксированную ширину
                    .height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6200EA)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(text = "Войти", color = Color.White, fontSize = 18.sp)
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Кнопка «Регистрация»
            Button(
                onClick = { navController.navigate("register_screen") },
                modifier = Modifier
                    .width(200.dp) // Установите фиксированную ширину
                    .height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6200EA)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(text = "Регистрация", color = Color.White, fontSize = 18.sp)
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Подсказка для регистрации
            Text(
                text = "Если у вас нет нашей бонусной карты, зарегистрируйтесь",
                color = Color.White,
                fontSize = 12.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

// Функция для проверки входа и отправки запроса на сервер
suspend fun verifyLogin(phone: String): Boolean {
    val url = "http://2.135.218.2/ut_api/hs/api/get_bonuses/?tel=$phone"
    val client = HttpClient(CIO)

    return try {
        val response: HttpResponse = client.get(url)
        response.status.value == 200
    } catch (e: Exception) {
        false
    }
}
