package com.example.amarantbonuscompose

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.ui.geometry.Offset
import kotlin.collections.listOf



@Composable
fun ProfileScreen(navController: NavHostController) {
    var currentLanguage by remember { mutableStateOf("RUS") }
    val context = LocalContext.current

    fun getText(russian: String, kazakh: String): String {
        return if (currentLanguage == "RUS") russian else kazakh
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color(0xFFD5006D),
                        Color(0xFF050206),
                        Color(0xFF050206),
                        Color(0xFF7438C3)
                    ),
                    start = Offset(0f, 0f),
                    end = Offset.Infinite
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Верхняя панель с кнопкой "назад" и языковой кнопкой
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { navController.popBackStack() }) { // Реализована навигация назад
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Назад",
                        tint = Color.White
                    )
                }

                // Кнопка смены языка
                Button(
                    onClick = {
                        currentLanguage = if (currentLanguage == "RUS") "KAZ" else "RUS"
                    },
                    modifier = Modifier
                        .size(width = 40.dp, height = 50.dp), // Размер кнопки
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFC107)),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = if (currentLanguage == "RUS") "ЯЗЫК" else "ТІЛ",
                            fontSize = 10.sp, // Размер текста
                            textAlign = TextAlign.Center,
                            color = Color.White
                        )
                        Text(
                            text = currentLanguage,
                            fontSize = 10.sp, // Размер текста
                            textAlign = TextAlign.Center,
                            color = Color.White
                        )
                    }
                }
            }

            // Информация о пользователе
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.8f), shape = RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Column {
                    UserInfoRow(
                        label = getText("Фамилия Имя", "Тегі Аты"),
                        value = "Зхс"
                    )
                    UserInfoRow(
                        label = getText("Дата рождения", "Туған күні"),
                        value = "06.06.2002"
                    )
                    UserInfoRow(
                        label = getText("Номер телефона", "Телефон нөмірі"),
                        value = "7472002609"
                    )
                    UserInfoRow(
                        label = getText("Город", "Қала"),
                        value = "Алматы"
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Текст "Больше информации об AMARANT" с нужным стилем и расположением прямо над кнопкой "Интернет магазин"
            Text(
                text = "Больше информации об\nAMARANT вы найдете по\nследующим ссылкам",
                fontSize = 16.sp, // Размер текста
                color = Color.White,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 0.dp) // Уменьшенный отступ снизу, чтобы текст был впритык к кнопке
            )

            Spacer(modifier = Modifier.height(8.dp)) // Минимальный отступ между текстом и кнопками

            // Центрированные кнопки с одинаковыми размерами и расстоянием между ними
            Column(
                modifier = Modifier
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                ExternalLinkButton(
                    text = "Internet магазин",
                    icon = painterResource(id = R.drawable.ic_cart),
                    onClick = {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.amarant.kz"))
                        context.startActivity(intent)
                    },
                    modifier = Modifier
                        .width(240.dp) // Одинаковая ширина
                        .height(50.dp) // Одинаковая высота
                        .padding(bottom = 12.dp) // Расстояние между кнопками
                )

                ExternalLinkButton(
                    text = "INSTAGRAM",
                    icon = painterResource(id = R.drawable.ic_instagram),
                    onClick = {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/amarant.kz/"))
                        context.startActivity(intent)
                    },
                    modifier = Modifier
                        .width(240.dp) // Одинаковая ширина
                        .height(50.dp) // Одинаковая высота
                        .padding(bottom = 12.dp) // Расстояние между кнопками
                )

                ExternalLinkButton(
                    text = "YOUTUBE",
                    icon = painterResource(id = R.drawable.ic_youtube),
                    onClick = {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://youtube.com/@amarantkz?si=lmg_WCSBYAMK9nwg"))
                        context.startActivity(intent)
                    },
                    modifier = Modifier
                        .width(240.dp) // Одинаковая ширина
                        .height(50.dp) // Одинаковая высота
                )
            }
        }
    }
}

@Composable
fun ExternalLinkButton(
    text: String,
    icon: androidx.compose.ui.graphics.painter.Painter,
    onClick: () -> Unit,
    modifier: Modifier = Modifier // Возможность передать модификатор для изменения кнопки
) {
    Button(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9C27B0))
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = icon,
                contentDescription = text,
                modifier = Modifier.size(24.dp),
                contentScale = ContentScale.Fit
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = text,
                color = Color.White,
                fontSize = 16.sp
            )
        }
    }
}

@Composable
fun UserInfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Text(
            text = value,
            fontSize = 16.sp,
            color = Color.White
        )
    }
}
