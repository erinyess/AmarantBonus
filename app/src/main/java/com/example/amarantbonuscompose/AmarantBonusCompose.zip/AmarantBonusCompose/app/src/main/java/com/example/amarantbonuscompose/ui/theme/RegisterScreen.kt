package com.example.amarantbonuscompose

// Imports
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.*
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.navigation.NavHostController
import com.chargemap.compose.numberpicker.NumberPicker
import java.util.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.geometry.Offset
import androidx.compose.material.icons.filled.ArrowDropDown

@Composable
fun RegisterScreen(navController: NavHostController) {
    var currentLanguage by remember { mutableStateOf("RUS") }

    fun getText(russian: String, kazakh: String): String {
        return if (currentLanguage == "RUS") russian else kazakh
    }

    var name by remember { mutableStateOf("") }
    var phoneNumber by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var selectedCity by remember { mutableStateOf(getText("Алматы", "Алматы")) }
    val cities = listOf(
        getText("Алматы", "Алматы"),
        getText("Нур-Султан", "Нұр-Сұлтан"),
        getText("Шымкент", "Шымкент"),
        getText("Атырау", "Атырау"),
        getText("Актобе", "Ақтөбе")
        // Добавьте больше городов при необходимости
    )

    // Компоненты даты рождения
    var birthDay by remember { mutableStateOf(1) }
    var birthMonth by remember { mutableStateOf(1) }
    var birthYear by remember { mutableStateOf(2000) }

    // Для раскрывающегося меню выбора города
    var expandedCity by remember { mutableStateOf(false) }

    // Для переключения видимости пароля
    var passwordVisible by remember { mutableStateOf(false) }

    // Состояние прокрутки для вертикального скроллинга
    val scrollState = rememberScrollState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color(0xFF800080), // Сиреневый слева сверху
                        Color(0xFF000000)  // Черный к центру и вниз
                    ),
                    start = Offset(0f, 0f),
                    end = Offset(500f, 1000f)
                )
            )
    ) {
        // Верхняя панель с переключателем языка (обновленная кнопка)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .align(Alignment.TopEnd),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Кнопка переключения языка
            Button(
                onClick = {
                    currentLanguage = if (currentLanguage == "RUS") "KAZ" else "RUS"
                },
                modifier = Modifier
                    .size(width = 30.dp, height = 40.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFFFFC107)),
                contentPadding = PaddingValues(0.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (currentLanguage == "RUS") "ЯЗЫК" else "ТІЛ",
                        fontSize = 8.sp,
                        textAlign = TextAlign.Center,
                        color = Color.White
                    )
                    Text(
                        text = currentLanguage,
                        fontSize = 8.sp,
                        textAlign = TextAlign.Center,
                        color = Color.White
                    )
                }
            }
        }

        // Основной контент
        Column(
            modifier = Modifier
                .fillMaxSize()
                .align(Alignment.Center)
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Заголовок
            val annotatedString = buildAnnotatedString {
                withStyle(
                    style = SpanStyle(
                        color = Color.White,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    )
                ) {
                    append(getText("РЕГИСТРАЦИЯ ", "ТІРКЕЛУ "))
                }
                withStyle(
                    style = SpanStyle(
                        color = Color.White,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    )
                ) {
                    append("В ")
                }
                withStyle(
                    style = SpanStyle(
                        color = Color(0xFFFFD700),
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    )
                ) {
                    append(getText("БОНУСНОЙ СИСТЕМЕ", "БОНУС ЖҮЙЕСІНДЕ"))
                }
            }

            Text(
                text = annotatedString,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .padding(bottom = 16.dp)
                    .background(
                        brush = Brush.horizontalGradient(
                            colors = listOf(
                                Color(0xFF800080),
                                Color(0xFF000000)
                            )
                        ),
                        shape = RoundedCornerShape(8.dp)
                    )
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                maxLines = 2
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Поле "Фамилия Имя"
            Text(
                text = getText("Фамилия Имя", "Тегі Аты"),
                color = Color.White,
                modifier = Modifier.fillMaxWidth(),
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                placeholder = { Text(text = getText("Введите фамилию и имя", "Тегі мен атыңызды енгізіңіз"), color = Color.Gray) },
                modifier = Modifier
                    .width(250.dp)
                    .height(56.dp),
                textStyle = TextStyle(color = Color.Black, fontSize = 14.sp),
                singleLine = true,
                colors = TextFieldDefaults.outlinedTextFieldColors(
                    backgroundColor = Color.White,
                    cursorColor = Color.Black,
                    focusedBorderColor = Color.Gray,
                    unfocusedBorderColor = Color.LightGray,
                    placeholderColor = Color.Gray,
                    textColor = Color.Black
                )
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Поле "Номер телефона"
            Text(
                text = getText("Номер телефона", "Телефон нөмірі"),
                color = Color.White,
                modifier = Modifier.fillMaxWidth(),
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            OutlinedTextField(
                value = phoneNumber,
                onValueChange = { phoneNumber = it },
                placeholder = { Text(text = "777 777 7777", color = Color.Gray) },
                leadingIcon = {
                    Text("+7", color = Color.Black, fontSize = 14.sp, modifier = Modifier.padding(start = 8.dp))
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier
                    .width(250.dp)
                    .height(56.dp),
                textStyle = TextStyle(color = Color.Black, fontSize = 14.sp),
                singleLine = true,
                colors = TextFieldDefaults.outlinedTextFieldColors(
                    backgroundColor = Color.White,
                    cursorColor = Color.Black,
                    focusedBorderColor = Color.Gray,
                    unfocusedBorderColor = Color.LightGray,
                    placeholderColor = Color.Gray,
                    textColor = Color.Black,
                    leadingIconColor = Color.Black
                )
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Поле "Новый пароль"
            Text(
                text = getText("Новый пароль", "Жаңа құпия сөз"),
                color = Color.White,
                modifier = Modifier.fillMaxWidth(),
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Text(
                text = getText("Цифрами. Не более 6 знаков", "Санмен. 6 таңбадан аспауы керек"),
                color = Color.White,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 4.dp),
                fontSize = 10.sp,
                textAlign = TextAlign.Center
            )
            OutlinedTextField(
                value = password,
                onValueChange = { if (it.length <= 6) password = it },
                placeholder = { Text(text = "123456", color = Color.Gray) },
                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                trailingIcon = {
                    val image = if (passwordVisible)
                        Icons.Default.Visibility
                    else
                        Icons.Default.VisibilityOff

                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Icon(imageVector = image, contentDescription = null, tint = Color.Gray)
                    }
                },
                modifier = Modifier
                    .width(250.dp)
                    .height(56.dp),
                textStyle = TextStyle(color = Color.Black, fontSize = 14.sp),
                singleLine = true,
                colors = TextFieldDefaults.outlinedTextFieldColors(
                    backgroundColor = Color.White,
                    cursorColor = Color.Black,
                    focusedBorderColor = Color.Gray,
                    unfocusedBorderColor = Color.LightGray,
                    placeholderColor = Color.Gray,
                    textColor = Color.Black,
                    trailingIconColor = Color.Gray
                )
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Поле "Дата рождения"
            Text(
                text = getText("Дата рождения", "Туған күні"),
                color = Color.White,
                modifier = Modifier.fillMaxWidth(),
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Box(
                modifier = Modifier
                    .width(250.dp)
                    .height(150.dp)
                    .background(Color.White, shape = RoundedCornerShape(8.dp))
            ) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // День
                    NumberPicker(
                        value = birthDay,
                        onValueChange = { birthDay = it },
                        range = 1..31,
                        textStyle = TextStyle(color = Color.Black, fontSize = 14.sp),
                        dividersColor = Color.Gray
                    )
                    // Месяц
                    NumberPicker(
                        value = birthMonth,
                        onValueChange = { birthMonth = it },
                        range = 1..12,
                        textStyle = TextStyle(color = Color.Black, fontSize = 14.sp),
                        dividersColor = Color.Gray
                    )
                    // Год
                    NumberPicker(
                        value = birthYear,
                        onValueChange = { birthYear = it },
                        range = 1900..Calendar.getInstance().get(Calendar.YEAR),
                        textStyle = TextStyle(color = Color.Black, fontSize = 14.sp),
                        dividersColor = Color.Gray
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Кнопка "Ваш город"
            Button(
                onClick = { expandedCity = true },
                modifier = Modifier
                    .width(250.dp)
                    .height(56.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(backgroundColor = Color.White),
                contentPadding = PaddingValues(0.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = getText("Ваш город", "Сіздің қалаңыз"),
                        color = Color.Black,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(start = 16.dp)
                    )
                    Icon(
                        imageVector = Icons.Default.ArrowDropDown,
                        contentDescription = null,
                        tint = Color.Black,
                        modifier = Modifier.padding(end = 16.dp)
                    )
                }
            }

            DropdownMenu(
                expanded = expandedCity,
                onDismissRequest = { expandedCity = false },
                modifier = Modifier
                    .width(250.dp)
            ) {
                cities.forEach { city ->
                    DropdownMenuItem(onClick = {
                        selectedCity = city
                        expandedCity = false
                    }) {
                        Text(text = city)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Кнопка "Зарегистрироваться"
            Button(
                onClick = {
                    // TODO: Добавьте логику регистрации
                    navController.navigate("main_screen")
                },
                shape = RoundedCornerShape(50.dp),
                modifier = Modifier
                    .width(250.dp)
                    .height(50.dp),
                colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF9C27B0))
            ) {
                Text(
                    text = getText("Зарегистрироваться", "Тіркелу"),
                    color = Color.White,
                    fontSize = 16.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
