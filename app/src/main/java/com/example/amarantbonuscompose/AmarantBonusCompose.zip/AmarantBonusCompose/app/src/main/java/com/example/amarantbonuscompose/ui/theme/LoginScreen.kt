package com.example.amarantbonuscompose

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.navigation.NavHostController
import androidx.compose.ui.text.style.TextAlign
import io.ktor.client.*
import io.ktor.client.engine.cio.*
import io.ktor.client.request.*
import io.ktor.client.statement.*
import io.ktor.client.plugins.logging.*
import kotlinx.coroutines.*

@Composable
fun LoginScreen(navController: NavHostController) {
    var currentLanguage by remember { mutableStateOf("RUS") }
    var showLoginFields by remember { mutableStateOf(false) }
    var phoneNumber by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var responseMessage by remember { mutableStateOf("") }

    val client = HttpClient(CIO) {
        install(Logging) {
            level = LogLevel.ALL
        }
    }

    fun getText(russian: String, kazakh: String): String {
        return if (currentLanguage == "RUS") russian else kazakh
    }

    suspend fun sendLoginRequest(phone: String) {
        try {
            val response: HttpResponse = client.get("http://2.135.218.2/ut_api/hs/api/get_bonuses/?tel=$phone")
            responseMessage = response.bodyAsText()

            if (response.status.value == 200) {
                navController.navigate("main_screen")
            } else {
                responseMessage = "Ошибка: ${response.status.description}"
            }
        } catch (e: Exception) {
            responseMessage = "Ошибка подключения: ${e.message}"
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color(0xFFD84386),
                        Color(0xFF050206),
                        Color(0xFF040008)
                    ),
                    start = Offset(0f, 0f),
                    end = Offset.Infinite
                )
            )
    ) {
        // Кнопка смены языка
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.End
        ) {
            Button(
                onClick = {
                    currentLanguage = if (currentLanguage == "RUS") "KAZ" else "RUS"
                },
                modifier = Modifier.size(30.dp, 40.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFFFFC107)),
                contentPadding = PaddingValues(0.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = getText("ЯЗЫК", "ТІЛ"),
                        fontSize = 8.sp,
                        textAlign = TextAlign.Center,
                        color = Color.White
                    )
                    Text(
                        text = currentLanguage,
                        fontSize = 8.sp,
                        textAlign = TextAlign.Center,
                        color = Color.White
                    )
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Логотип и название
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.wrapContentSize()
            ) {
                Image(
                    painter = painterResource(id = R.drawable.new_image), // Замените на ваш ресурс
                    contentDescription = "Логотип",
                    modifier = Modifier.size(80.dp)
                )

                Spacer(modifier = Modifier.width(4.dp))

                Text(
                    text = "AMARANT",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            // "GASTROMARKETI" под "AMARANT"
            Text(
                text = "GASTROMARKETI",
                fontSize = 8.sp,
                fontWeight = FontWeight.Normal,
                color = Color.White,
                modifier = Modifier
                    .offset(y = (-25).dp)
                    .align(Alignment.Start)
                    .padding(start = 195.dp)
            )

            Spacer(modifier = Modifier.height(40.dp))

            // Кнопка «БОНУСНАЯ СИСТЕМА» с разноцветным текстом
            Button(
                onClick = { navController.navigate("bonus_system") },
                colors = ButtonDefaults.buttonColors(
                    backgroundColor = Color.Transparent
                ),
                shape = RoundedCornerShape(10.dp),
                elevation = ButtonDefaults.elevation(0.dp),
                modifier = Modifier
                    .fillMaxWidth(0.9f)
                    .height(100.dp)
                    .background(
                        brush = Brush.horizontalGradient(
                            colors = listOf(
                                Color(0xFFDB2E97),
                                Color(0xFF000000),
                                Color(0xFF000000)
                            )
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ),
                contentPadding = PaddingValues()
            ) {
                Text(
                    text = buildAnnotatedString {
                        withStyle(style = SpanStyle(color = Color.White)) {
                            append(getText("БОНУСНАЯ ", "БОНУС "))
                        }
                        withStyle(style = SpanStyle(color = Color(0xFFFFD700))) {
                            append(getText("СИСТЕМА", "ЖҮЙЕСІ"))
                        }
                    },
                    fontSize = 28.sp,
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            if (showLoginFields) {
                // Поле для ввода номера телефона
                OutlinedTextField(
                    value = phoneNumber,
                    onValueChange = { phoneNumber = it },
                    label = { Text(getText("Введите номер телефона", "Телефон нөмірін енгізіңіз")) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        backgroundColor = Color.Transparent,
                        focusedBorderColor = Color.White,
                        unfocusedBorderColor = Color.White,
                        textColor = Color.White
                    )
                )

                // Поле для ввода пароля с серым фоном и иконкой глаза
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text(getText("Введите пароль", "Құпия сөзді енгізіңіз")) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        val image = if (passwordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(imageVector = image, contentDescription = null)
                        }
                    },
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        backgroundColor = Color.Gray,
                        focusedBorderColor = Color.Gray,
                        unfocusedBorderColor = Color.Gray,
                        textColor = Color.White
                    )
                )
            }

            // Кнопка «Войти»
            Button(
                onClick = { showLoginFields = true },
                colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF9C27B0)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .width(250.dp)
                    .height(50.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        painter = painterResource(id = R.drawable.ic_out_phone_icon), // Замените на ваш ресурс
                        contentDescription = "Иконка Войти",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = getText("Войти", "Кіру"), color = Color.White, fontSize = 18.sp)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Текст о регистрации
            Text(
                text = getText(
                    "Если у вас нет нашей бонусной карты, зарегистрируйтесь",
                    "Егер Сізде біздің бонус картамыз болмаса, тіркеліңіз"
                ),
                fontSize = 14.sp,
                color = Color.White,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Кнопка «Регистрация»
            Button(
                onClick = { navController.navigate("register_screen") },
                colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF9C27B0)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .width(250.dp)
                    .height(50.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        painter = painterResource(id = R.drawable.ic_person_icon), // Замените на ваш ресурс
                        contentDescription = "Иконка Регистрация",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = getText("Регистрация", "Тіркелу"), color = Color.White, fontSize = 18.sp)
                }
            }

            Spacer(modifier = Modifier.height(40.dp))

            // Версия приложения
            Text(
                text = "v. 1.0",
                fontSize = 12.sp,
                color = Color.White,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(end = 16.dp)
                    .wrapContentWidth(Alignment.End)
            )
        }
    }
}
